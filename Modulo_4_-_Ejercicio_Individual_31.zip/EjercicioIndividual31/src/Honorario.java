public class Honorario extends Trabajador {

    private int giro;
    private int anioIniciacion;

    public Honorario(int giro, int anioIniciacion) {
        this.giro = giro;
        this.anioIniciacion = anioIniciacion;
    }

    public Honorario(String nombres, String apellidos, String run, int telefono, int edad, int giro, int anioIniciacion) {
        super(nombres, apellidos, run, telefono, edad);
        this.giro = giro;
        this.anioIniciacion = anioIniciacion;
    }

    public int getGiro() {
        return giro;
    }

    public void setGiro(int giro) {
        this.giro = giro;
    }

    public int getAnioIniciacion() {
        return anioIniciacion;
    }

    public void setAnioIniciacion(int anioIniciacion) {
        this.anioIniciacion = anioIniciacion;
    }

    public void mostrarDatos(){
        System.out.println("### Datos Trabajador Honorario ###");
        System.out.println("Giro: "+this.giro);
        System.out.println("Año de iniciación de actividades: "+this.anioIniciacion);

    }

    @Override
    public String toString() {
        return "Honorario{" +
                "giro='" + giro + '\'' +
                ", anioIniciacion=" + anioIniciacion +
                '}';
    }
}
