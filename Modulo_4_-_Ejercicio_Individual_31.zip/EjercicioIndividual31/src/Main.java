public class Main {

    public static void main(String[] args){

        Trabajador trabajador = new Trabajador("Roberto", "Rivas", "15421652-5",456789,64);
        Trabajador trabajador2 = new Trabajador("Bastián", "Mariangel", "18907352-6",95123456,28);
        Trabajador trabajador3 = new Trabajador("Patricio", "Bonnin", "16228852-2",32698789,25);

        Honorario trabajador4 = new Honorario("Ivan", "Mieres", "1515454",787878787, 20,500000, 1999);
        Contratado trabajador5 = new Contratado("Sebastian", "Hernandez", "18797254",56456456, 35,"10/05/1950", 800000);
        Eventual trabajador6 = new Eventual("Carlos", "Mendez", "9876542",132465321, 25,true, "asdasd@gmail.com");

        trabajador4.mostrarDatos();
        trabajador5.mostrarDatos();
        trabajador6.mostrarDatos();

        System.out.println(trabajador.toString());
        System.out.println(trabajador2.toString());
        System.out.println(trabajador3.toString());

    }
}
