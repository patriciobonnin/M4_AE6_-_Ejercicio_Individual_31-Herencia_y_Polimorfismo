public class Eventual extends Trabajador{


    private boolean disponibilidad;
    private String email;

    public Eventual(boolean disponibilidad, String email) {
        this.disponibilidad = disponibilidad;
        this.email = email;
    }

    public Eventual(String nombres, String apellidos, String run, int telefono, int edad, boolean disponibilidad, String email) {
        super(nombres, apellidos, run, telefono, edad);
        this.disponibilidad = disponibilidad;
        this.email = email;
    }


    public boolean isDisponibilidad() {
        return disponibilidad;
    }

    public void setDisponibilidad(boolean disponibilidad) {
        this.disponibilidad = disponibilidad;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }


    public void mostrarDatos(){
        System.out.println("### Datos Trabajador Eventual ###");
        System.out.println("Disponibilidad: "+this.disponibilidad);
        System.out.println("Email: "+this.email);

    }

    @Override
    public String toString() {
        return "Eventual{" +
                "disponibilidad=" + disponibilidad +
                ", email='" + email + '\'' +
                '}';
    }
}
